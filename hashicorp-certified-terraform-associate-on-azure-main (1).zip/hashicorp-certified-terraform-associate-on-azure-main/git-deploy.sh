#!/bin/sh

echo "Add files and do local commit"
git add .
git commit -am "Welcome to StackSimplify by Kalyan Reddy Daida"

echo "Pushing to Github Repository"
git push
